import React from "react";

function Board() {
  return <div>BOARD</div>;
}

export default Board;
