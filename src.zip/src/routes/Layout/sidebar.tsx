import React from "react";

export default function Sidebar() {
  return (
    <div className="fixed z-10 top-32 sidebar w-60 h-96 bg-pink-200">asdf</div>
  );
}
